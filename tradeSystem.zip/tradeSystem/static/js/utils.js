
function print()  {
	console.log("hello world");
}

